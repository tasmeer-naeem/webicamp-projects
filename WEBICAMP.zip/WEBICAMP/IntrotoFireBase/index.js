var auth  = firebase.auth();
var firestore = firebase.firestore();

//console.log(firestore)

//create
/*var newuser={
    name : "tasmeer",
    email : "tas27@gmail.com"
} */

//firestore.collection("users").doc("123").set(newuser)
//firestore.collection("users").doc("789").set(newuser)
//firestore.collection("users").add(newuser)

/*var users = firestore.collection("users").get().then((response)=>{
    response.forEach(doc=>{ 
    console.log(doc.data())
    });
}) */

/*var fetchuser = async ()  =>{
    var users = await firestore.collection("users").get()
    users.forEach(doc=>{
        console.log(doc.data())
    });
}

var fetchspecificuser = async (docId)  =>{
    var user = await firestore.collection("users").doc(docId).get();
    console.log(user.data());
}

var updatedspecificuser = async (updatedobj,docId)  =>{
     await firestore.collection("users").doc(docId).update(updatedobj);  
}

var newobj={
    name : "Steve"
}

var deletespecificuser = async (docId)  =>{
    try{
    await firestore.collection("users").doc(docId).delete();  
    }
    catch(error){
        console.log(error);
    }
} */

//fetchuser();
//fetchspecificuser("789")
//updatedspecificuser(newobj,"789")
//deletespecificuser("789")

var signupform=document.querySelector(".signupform")
var fullnamesignup=document.querySelector(".fullnamesignup")
var emailsignup=document.querySelector(".emailsignup")
var passwordsignup=document.querySelector(".passsignup")

var signinform=document.querySelector(".signinform")
var emailsignin=document.querySelector(".emailsignin")
var passwordsignin=document.querySelector(".passsignin")

signupform.addEventListener("submit", async (e)=>{
    e.preventDefault();
    try{
        var fullname = fullnamesignup.value
        var email = emailsignup.value
        var password = passwordsignup.value
        var signeduser=await auth. createUserWithEmailAndPassword(fullname,email,password);
       // console.log(signeduser)    
        var userobj = {
            displayname : fullname , 
            email : email
        }
        //console.log("done")
        await firestore.collection("users").doc(signeduser.user.uid).set(userobj);
    }
    catch(error){
        console.log(error.message);
    }
}
)

signinform.addEventListener("submit", async (e)=>{
    e.preventDefault();
    try{
        var email = emailsignin.value
        var password = passwordsignin.value
        var loggeduser= await auth. signInWithEmailAndPassword(email,password);
        //console.log(loggeduser)    
    var userinfo = await firestore.collection("users").doc(loggeduser.user.uid).set(userobj).get();
        console.log(userinfo.data())
    }
    catch(error){
        console.log(error.message);
    }
}
)

