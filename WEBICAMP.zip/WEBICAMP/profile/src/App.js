import React from "react"
import {BrowserRouter,Route,Switch} from "react-router-dom"
import Home from "./Pages/Home/Home"
import Profiles from "./Pages/Profiles/Profiles"
import Details from "./Pages/Details/Details"


function App() {
  return (
   <BrowserRouter>
   <Switch>
     <Route path="/" component={Home} exact ></Route>
     <Route path="/Profiles" component={Profiles} exact></Route>
     <Route path="/Profiles/:Profile_id" component={Details} ></Route>
   </Switch>
   </BrowserRouter>
  );
}

export default App;
