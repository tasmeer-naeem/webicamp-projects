import React from "react"
import Cards from "../../Components/Cards/Cards"




class Details  extends React.Component{
    state={
        profile:{}
    }
componentDidMount = async() => {
    var profileId = this.props.match.params.profile_id
    var data = await fetch(`https://jsonplaceholder.typicode.com/users/${profileId}`) 
    var profile = await data.json()
    console.log(profile)
    this.setState({
        profile:profile
    })
}


    render(){
       // console.log(this.props)
      //  console.log(this.props.match.params.profile_id)
     // console.log(this.state.profile)
    return(
        <div>
           <h1> details page</h1>
           <Cards  profile={this.state.profile_id}/> 
        
        </div>
    )
}
}
export default Details