import React from "react"
import Cards from "./../../Components/Cards/Cards"


class profiles extends React.Component{

    state={
        profiles:[]
    }

componentDidMount = async() => {
    var data=await fetch("https://jsonplaceholder.typicode.com/users");
    var profiless=await data.json();
    this.setState({
        profiles:[...this.state.profiles,...profiless]
    })
}

render(){
//console.log(this.state.profiles)
    return(
        <div>
           <h1> profiles page</h1>
           {this.state.profiles.map((profile)=> <Cards key={profile.id}  profile={profile} />)}
           
        </div>
    )
}
}
export default profiles