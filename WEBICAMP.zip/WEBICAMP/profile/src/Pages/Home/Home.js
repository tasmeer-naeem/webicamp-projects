import React from "react"
import {Link} from "react-router-dom"

var home=()=>{
    return(
        <div>
            <h1>Profiler</h1>
            <Link to="Profiles">
            <button>View Profiles</button>
            </Link>
            
        </div>
    )
}

export default home