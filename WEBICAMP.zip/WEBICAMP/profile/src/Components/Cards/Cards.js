import React from "react"
import {Link,withRouter} from "react-router-dom"


const Cards=(props)=>{
    var {profile : {id,name,email} ,match:{params :{profile_id}} }=props
    
    return(
       
        <div>
            <h1>{id}{name}</h1>
            <h3>{email}</h3>
           { profile_id  ? null  : <Link to={`/profiles/${id}`}  >
            <button>View Details</button>
            </Link> }
            
            ------------------------------
        </div>
    )
}

export default withRouter(Cards)