
var CounterAction=()=>{
  return(
        type="INCREMENT_COUNTER" //ins
  );
}

var CounterAction=()=>{
    return(
          type="DECREMENT_COUNTER" //ins
    );
  }

export default CounterAction;