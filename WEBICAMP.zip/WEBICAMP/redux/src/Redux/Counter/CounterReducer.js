var initialstate =0;

var CounterReducer =(state= initialstate , action)=>{
   var {type,payload} =action;
  switch(type){
      case "INCREMENT_COUNTER"  :
       return state + 1
       case "DECREMENT_COUNTER"  :
       return state - 1
       default :
       return state ;
  }
}

export default CounterReducer;