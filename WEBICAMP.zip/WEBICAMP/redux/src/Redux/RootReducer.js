import {combineReducers} from  "redux"
import CounterReducer from "./Counter/CounterReducer"

var RootReducer  = combineReducers({
    counter : CounterReducer,
})

export default RootReducer;