import {createStore,applyMiddleware} from "redux"
import RootReducer from "./RootReducer"
import {composeWithDevTools} from "redux-devtools-extension"

var middlewares=[];

var Store = createStore(
    RootReducer,
    composeWithDevTools,
    applyMiddleware(...middlewares));

export default Store;