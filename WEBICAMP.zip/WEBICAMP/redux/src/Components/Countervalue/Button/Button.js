import react from "react"
import {increamentCounter,decreamentCounter} from "./../../Redux/Counter/CounterAction"

var Button =(props)=>{
    return(

        <div>
            <button onClick={props.increamentCounter}>+</button>
            <button onClick={props.decreamentCounter}>-</button>
        </div>
    )
}

var actions = {
    increamentCounter,
    decreamentCounter
}

export default connect(null,actions)(Button)