import raect from "react"
import Button from "./..//Button/Buttons"
import {connect}   from "react-redux"

var Countervalue =(Props)=>{
    //console.log(Props.Counter)
    return(
        <div>
            {Props.Counter}
            <Button/>
        </div>
    )
}

mapstate=(store)=>{
    return(
    Counter=store.Counter
    )
}

export default connect(mapState)(Countervalue);