import React from "react"
import { BrowserRouter as Router,Switch,Route } from "react-router-dom"
import Navbar from "./Components/Navbar/Navbar"
import Home from "./Pages/Home/Home"
import Info from "./Pages/Info/Info"

var App=()=>{
  return (
   <div>
     <Router>
     <Navbar/>
      <Switch>
        <Route path='/' component={Home} exact/>
        <Route path='/transaction/:transactionId' component={Info}/>
      </Switch>
     </Router>
   </div>
  );
}

export default App;
