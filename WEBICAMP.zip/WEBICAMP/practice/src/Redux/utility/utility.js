
export var calculateamount=(transactions)=>{
    var sum =0;
    for (var transaction of transactions){
        var {transsactiontype,amount}=transaction;
        if(transsactiontype==="income") sum+=amount
        else sum-=amount

    }
    return sum;

}

export var updatetransactiondata =(transaction,transactionId,updateddata)=>{
    return(
    transaction.map ((trans) => {
        if(trans.id === transactionId){
        return{
            ...trans,
            ...updateddata
        }
      }
      else {
          return {
              ...trans
          }
      }
    })

    )
}