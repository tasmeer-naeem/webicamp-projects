import {combineReducers} from "redux"
import transactionreducer from "./transaction/transactionreducer";


const RootReducer=combineReducers({
        transactions : transactionreducer
})

export default RootReducer;