import {ADD_TRANSACTION, DELETE_TRANSACTION, UPDATE_TRANSACTION} from "./transactionconstant"
import {updatetransactiondata} from "./../utility/utility"
var initialstate=[]

const transactionreducer=(state=initialstate,action)=>{
     var {type,payload} = action ;
     switch(type){
         case ADD_TRANSACTION:
             return [...state, payload.transaction]
         case DELETE_TRANSACTION  :
              return state.filter((trans)=>  trans.id !== payload.transactionId)
         case UPDATE_TRANSACTION :
              return updatetransactiondata(
                  state,
                  payload.transactionId,
                  payload.updateddata
              )
        default :
        return 
     }
}

export default transactionreducer;