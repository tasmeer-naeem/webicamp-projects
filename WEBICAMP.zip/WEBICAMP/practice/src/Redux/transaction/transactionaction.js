import {ADD_TRANSACTION,DELETE_TRANSACTION,UPDATE_TRANSACTION} from "./transactionconstant"

export var addtransaction=(transactionobj)=>({
    type : ADD_TRANSACTION ,
   payload :{
        transaction : transactionobj
   } 
})

export var deletetransaction=(transactionId)=>({
     type : DELETE_TRANSACTION ,
    payload :{
         transactionId
    } 
 })

 export var updatetransaction=(transactionId, updateddata)=>({
     type : UPDATE_TRANSACTION ,
    payload :{
          updateddata,
          transactionId
    } 
 })