/*import {createStore,applyMiddleware} from "redux"
import Rootreducer from "./rootreducer"
import {composeWithDevTools} from "redux-devtools-extension"
//import thunk from "redux-thunk"
//import reactRouterMiddleware from "react-router-middleware"
//import { reactRouterMiddleware } from 'react-router-redux' 
//import { reactRouterMiddleware } from 'connected-react-router'


 export var middlewares=[] ;


var store = createStore(Rootreducer,composeWithDevTools,(applyMiddleware(...middlewares)));
/*const store = createStore(
  Rootreducer,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__(),
  compose(applyMiddleware(thunk)),
);

/*const store = createStore(rootreducer,
        window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__(),
        applyMiddleware(thunk, reactRouterMiddleware));

/*
        const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
        const store = createStore(
          rootreducer,
          composeEnhancers(
            applyMiddleware(thunk, reactRouterMiddleware),
          )
        ); */


       import {createStore, applyMiddleware }  from "redux";
        import Rootreducer from "./rootreducer";
        import {composeWithDevTools} from "redux-devtools-extension" 
        
        export var middlewares  = [];
        
        var store = createStore(
                Rootreducer,
                composeWithDevTools(applyMiddleware(...middlewares))
                );  
        
       
export default store;