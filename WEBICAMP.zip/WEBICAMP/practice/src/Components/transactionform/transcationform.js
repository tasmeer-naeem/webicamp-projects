import React from "react"
import {v4 as uuid } from "uuid"
import {connect} from "react-redux"
import  {addtransaction, updatetransaction} from "..//../Redux/transaction/transactionaction"
import { withRouter } from "react-router-dom"
//import { withRouter } from "react-router-dom"

class transactionform extends React.Component {

    state={
        description : this.props.defaultvalues ? this.props.defaultvalues.description :  "",
        amount :  this.props.defaultvalues ? this.props.defaultvalues.amount : 0 ,
        transactiontype :  this.props.defaultvalues ? this.props.defaultvalues.transactiontype : "expense"
    }
  /*  handledescriptioninput=(e)=>{
        var value=e.target.value
        this.setState({
            description : value
        })
    }
    handleamountinput=(e)=>{
        var value = e.target.value
        this.setState({
            amount :value
        })   
    }
    handletransactiontypeinput=(e)=>{
        var value=e.target.value
        this.setState({
            transactiontype: value
        })
    }
*/
    handleforminput=(e)=>{
        var[name,value]=e.target
        this.setState=({
            [name]:value
        })

    }
    handleformsubmit=(e)=>{
        e.preventDefault();
        if(this.props.defaultvalues){
            var {match : {params : {transactionId}}, updatetransaction ,history :{goback}}= this.props;
            updatetransaction(transactionId,this.state)
            goback();

        }
        else{
            var transactionobj={
                ...this.state,
                amount : parseInt(this.state.amount),
                id : uuid()
        }
       
       }
    this.props.addtransaction(transactionobj)
    }
render=()=>{
    console.log(this.props)
    return(

    <form onSubmit={this.handleformsubmit}>
        <input value={this.state.description} onChange={this.handleforminput} placeholder="description" type="description"/>
        <input value={this.state.amount} onChange={this.handleforminput}placeholder="amount" type="amount"/>
        <select value={this.state.transactiontype} onChange={this.handleforminput}>
            <option>Expense</option>
            <option>Income</option>
        </select>
         {this.props.defaultvalues} ?  <button>Update</button> : <button>Add</button>
    </form>


    )
    
}

}
var action ={
    addtransaction ,
    updatetransaction

}
export default connect(null,action)(withRouter(transactionform));