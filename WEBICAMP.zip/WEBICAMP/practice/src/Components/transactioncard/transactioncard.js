import React from "react"
import {connect} from "react-redux"
import { Link } from "react-router-dom"
import {deletetransaction} from "./../../Redux/transaction/transactionaction"

var transactioncard=({deletetransaction,transaction :{description,amount,transactiontype,id}})=>{
    return(
        <div>
            <h2>{description}-{amount}-{transactiontype}</h2>
            <button onClick={()=>deletetransaction(id)}>DELETE</button><Link to={`/transaction/${id}`}><button>EDIT</button></Link> 
        </div>
    )
}
var action={
    deletetransaction
}

export default connect(null,action)(transactioncard);