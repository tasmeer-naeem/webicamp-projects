import React from "react"
import {connect} from "react-redux"
import Transactioncard from "../transactioncard/transactioncard"

var transactionlist=({transactions})=>{
   console.log(transactions)
   return(
       <div>
           <h1>list</h1>
           {transactions.map((transaction)=> <  Transactioncard key={transaction.id} transaction={transaction} /> )}
       </div>
   )

}

var mapState = (state) => ({
    transactions : state.transactions
})

export default connect(mapState)(transactionlist);