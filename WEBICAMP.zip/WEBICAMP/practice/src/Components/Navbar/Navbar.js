import React from "react"
import { calculateamount } from "../../Redux/utility/utility"
import {connect} from "react-redux"


var Navbar=({grossamount})=>{
    console.log(grossamount)
    return(
        <div >
            <h1>Navbar Page</h1>
            {grossamount}
        </div>
    )
}
var mapState=(state)=>({
    grossamount : calculateamount(state.transactions)

})

export default connect(mapState)(Navbar)