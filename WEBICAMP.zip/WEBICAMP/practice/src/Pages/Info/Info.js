import React from "react"
import {connect} from "react-redux"
import Transactionform from "../../Components/transactionform/transcationform"

var info=({ transaction })=>{
    console.log(transaction)
    return(
        <div>
            <h1>Info Page</h1>
            
            <Transactionform defaultvalues={transaction}/>
        </div>
    )
}
var mapState=(state,{match :{params : {transactionId}}})=>({
    transaction : state.transactions.find(transaction => transaction.id === transactionId)
})

export default connect(mapState)(info)