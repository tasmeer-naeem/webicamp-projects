import React from "react"
import Transactionform from "../../Components/transactionform/transcationform"
import Transactionlist from "./../../Components/transactionlist/transactionlist"

var home=()=>{
    return(
        <div>
            <h1>Home Page</h1>
            <Transactionform/>
            <Transactionlist/>
        </div>
    )
}

export default home