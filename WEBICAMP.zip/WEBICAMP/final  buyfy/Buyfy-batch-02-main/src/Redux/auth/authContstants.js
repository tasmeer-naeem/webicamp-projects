export const SET_USER = "SET_USER";
export const REMOVE_USER = "REMOVE_USER";