import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";

var firebaseConfig = {
  apiKey: "AIzaSyBm-XDPMiS8VIEFyzp3HdLYGOEGHPwOYAQ",
    authDomain: "buyfy-2021.firebaseapp.com",
    projectId: "buyfy-2021",
    storageBucket: "buyfy-2021.appspot.com",
    messagingSenderId: "272788825220",
    appId: "1:272788825220:web:352ef37cfb8b2eebe24ed1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export var auth = firebase.auth();
export var firestore = firebase.firestore();
export var googleAuthProvider = new firebase.auth.GoogleAuthProvider();
export var serverTimestamp = () => firebase.firestore.FieldValue.serverTimestamp();
export var storage = firebase.storage().ref()


export default firebase;
