import React from 'react';

var Header=()=>{
    return(
<div>
    <h1>TODO APP </h1>
</div>
    );
}

export default Header;