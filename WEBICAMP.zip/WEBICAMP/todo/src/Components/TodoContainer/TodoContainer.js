import React from 'react';
import Todo from "./../Todo/Todo"
import {connect} from "react-redux"

var TodoContainer=(props)=>{
    var filteredtodo=[];

    if(props.filter === "all"){
        filteredtodo=props.todos
    }
    else if(props.filter === "completed"){
        filteredtodo=props.todos.filter((todo)=> todo.isCompleted === true)
    }
    else if(props.filter === "active"){
        filteredtodo=props.todos.filter((todo)=> todo.isCompleted === false)
    }

   // console.log(props.todos)
    return(
        <div>
            {filteredtodo.todos.map((todoObj)=> <Todo key={todoObj.id} todoData={todoObj}  />)}
 
       </div>
    )
}
var mapState=(state)=>({

    todos : state.todos ,
    filter : state.filters.status
})

export default connect(mapState)(TodoContainer);



