import React from 'react';
import {connect} from "react-redux"
import {deletetodo,completetask,activetodo} from "./..//../Redux/todos/todoaction"


var Todo=(props)=>{
//console.log(props.todoData.id)

    return(
        <div>
        <h3>
            {props.todoData.description} 
            <button onClick={()=>props.completetask(props.todoData.id)}>COMPLETE</button> 
             <button onClick={()=>props.activetodo(props.todoData.id)}>ACTIVE</button> 
            <button onClick={()=>props.deletetodo(props.todoData.id)}> DELETE</button>
        </h3>
        </div>
    );
}
var action =({
    deletetodo ,
    completetask ,
    activetodo
})

export default connect(null,action)(Todo);

//onClick={() => props.handledeleteTodo (props.todo.id)}