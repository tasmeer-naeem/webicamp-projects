import {SET_FILTER_STATUS} from "./filterconstant" 
 
 var setfilterstatus =(status)=>({
     type : SET_FILTER_STATUS,
     payload : {
         status
     }
 })

 export default setfilterstatus;