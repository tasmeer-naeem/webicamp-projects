import {SET_FILTER_STATUS} from "./filterconstant"

var initialState={
    status : "all"
}

var filterreducer=(state=initialState,action) =>{
        var {type,payload} = action;
        switch (type){
            case SET_FILTER_STATUS :
                return {status : payload.status}
            default :
                return state
        }
}

export default filterreducer;