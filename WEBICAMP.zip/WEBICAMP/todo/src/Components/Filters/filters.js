import React from "react"
import setfilterstatus from "./filteraction"
import {connect} from "react-redux"


var Filter = (setfilterstatus) => {
  
   return(
       <div>
        <button onClick={()=> setfilterstatus("all") }>ALL</button>
        <button onClick={()=> setfilterstatus("completed") }>COMPLETED</button>
        <button onClick={()=> setfilterstatus("active") }>ACTIVE</button>
        </div>
   );

}
var action={
    setfilterstatus
}

export default connect(null,action)(Filter);