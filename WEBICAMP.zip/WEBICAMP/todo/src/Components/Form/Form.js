import React from 'react';
import {v4 as uuidv4}  from "uuid";
import {connect} from "react-redux";
import {addtodo} from "./..//../Redux/todos/todoaction"


class Form extends React.Component{
    state={
        todoinput:""
    }

changeinput=(e)=>{
   var value=e.target.value;
   //consiole.log(e.target.value);
   this.setState({
       todoinput:value
   });
};

onSubmit=(e)=>{
    e.preventDefault()
    var todoObj={
        description:this.state.todoinput,
        completed:false,
        id: uuidv4 
    } 
    this.props.addtodo(todoObj)   
}

render=()=>{
        return(
            <div>
                <form onSubmit={this.onSubmit}>        
                    <input onChange={this.changeinput} value={this.state.todoinput} type="text" placeholder="todo"></input><button>ADD</button>
                </form>
            </div>
        );
    }
}
var actions ={
    addtodo
}

export default connect(null,actions)(Form);