
import {ADD_TODO,DELETE_TODO,COMPLETE_TASK,ACTIVE_TODO,SERACH_TODO} from "./todoconstants"


export var addtodo=(todoobj)=>({
    type : ADD_TODO ,
    payload :{
        todo : todoobj
    }
})


export var deletetodo=(todoId)=>({
    type : DELETE_TODO ,
    payload : {
        todoId
    }
})

export var completetask=(todoId)=>({
    type : COMPLETE_TASK ,
    payload : {
        todoId
    }
})

export var activetodo=(todoId)=>({
    type : ACTIVE_TODO ,
    payload : {
        todoId
    }
})

export var searchtodo=(todoId)=>({
    type : SERACH_TODO ,
    payload : {
        todoId
    }
})



