
import { ADD_TODO, DELETE_TODO,COMPLETE_TASK,ACTIVE_TODO} from "./todoconstants"

var initialstate=[]

const todoreducer = (state=initialstate,action) => {
    var {type,payload} = action;
    switch(type){
        case ADD_TODO :
            return [...state, payload.todo]
        case DELETE_TODO :
            return state.filter((todo)  => todo.id !==  payload.todoId)
        case COMPLETE_TASK :
            return state.map((todo)=>{
                if(todo.id ===  payload.todoId){
                    return{
                        ...todo,
                        isCompleted : true
                    }
                }
                else{
                    return {...todo}
                }
                  
            })
        case ACTIVE_TODO :
            return state.map((todo)=>{
                if(todo.id ===  payload.todoId){
                    return{
                        ...todo,
                        isCompleted : false
                    }
                }
                else{
                    return {...todo}
                }
                 
                  
            })
        default :
            return state 
            
    }
    
}

export default todoreducer;