export const ADD_TODO =  "ADD_TODO";
export const DELETE_TODO =  "DELETE_TODO";
export const COMPLETE_TASK  =  "COMPLETE_TASK";
export const ACTIVE_TODO = "ACTIVE_TODO";
export const SERACH_TODO = "SEARCH_TODO"