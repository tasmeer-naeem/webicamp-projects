import {combineReducers} from "redux"
import filterreducer from "../Components/Filters/filterreducer";
import todoreducer from "./todos/todoreducer"

const Rootreducer=combineReducers({
        todos: todoreducer,
        filters: filterreducer
})

export default Rootreducer;