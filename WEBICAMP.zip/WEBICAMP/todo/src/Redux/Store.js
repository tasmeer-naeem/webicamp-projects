import {createStore, applyMiddleware }  from "redux";
import Rootreducer from "./Rootreducer";
import {composeWithDevTools} from "redux-devtools-extension" 

export var middlewares  = [];

var store = createStore(
        Rootreducer,
        composeWithDevTools(applyMiddleware(...middlewares))
        );

export default store;
