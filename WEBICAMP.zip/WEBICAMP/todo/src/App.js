
import React from 'react';
import Header from  "./Components/Header/Header"
import Form from "./Components/Form/Form"
import TodoContainer from './Components/TodoContainer/TodoContainer';
import Filter from './Components/Filters/filters';
//import Todo from './Components/Todo/Todo';

var App=()=> {
  return (
    <div>
     <Header/>
     <Form  />
     <TodoContainer />
     <Filter/>
    </div>
  );
}

export default App;
