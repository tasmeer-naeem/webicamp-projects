import React from "react"
import Lifecycle from  "./Components/Lifecycle/Lifecycle"
import logo from './logo.svg';
import './App.css';


class App extends React.Component {
    state={
      isShown:true,
      content:"hi"
    }

appendtext=()=>{
  this.setState({
    content: `${this.state.content} hi`
  })
}

togglecomponent=()=>{
  this.setState({
    isShown : !this.state.isShown
  })
}


  render=()=>{
  return (
    <div className="App">
      
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
       <button onClick={this.togglecomponent} >Toggle Lifecycle</button>
       <button onClick={this.appendtext} >Add Text</button>

       {/*conditional rendering*/}
       {this.state.isShown ? <Lifecycle content={this.state.content}/> : null}
    
    </div>
  );
}
}
export default App;
