import React from "react"

class lifecycle extends React.Component{
        constructor(){
            super()
            console.log("constructor")
        }

componentDidMount(){
    console.log("component did mount")
}
componentDidUpdate(){
    console.log("component did update")
}
componentWillUnmount(){
    console.log("component will unmount")
}
    render=()=>{
        console.log("render")
        return(
            <div>
                <h1>{this.props.content}</h1>
            </div>
        )
    }
}
    export default lifecycle;
