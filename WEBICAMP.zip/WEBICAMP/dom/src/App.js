import React from "react"
import {BrowserRouter,Route,Switch} from "react-router-dom"
import home from "./Pages/Home/Home"
import about from  "./Pages/About/About"
import contact from "./Pages/Contact/Contact"
import Navbar from "./Components/Navbar/Navbar"
import "./App.css"


  function App  (){
    
    return (
    <div>
     
  <BrowserRouter>
  <Navbar/> 
  <Switch>
      <Route path="/"  component={home} exact></Route>
      <Route path="/about" component={about}></Route>
      <Route path="/contact" component={contact}></Route>
  </Switch>
  </BrowserRouter>
    </div>
    );
  }  

  export default App;
