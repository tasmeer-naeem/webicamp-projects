import React from "react"


const about=()=>{
    return(
        <div>
            <h1>My about Page</h1>
        </div>
    );
}

export  default about;
