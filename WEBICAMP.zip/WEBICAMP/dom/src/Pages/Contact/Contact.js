import React from "react"


const contact=()=>{
    return(
        <div>
            <h1>My contact Page</h1>
        </div>
    )
}

export  default contact;
