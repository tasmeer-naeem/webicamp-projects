import React from "react"

const home=()=>{
    return(
        <div>
            <h1>My home Page</h1>
        </div>
    )
}

export  default home;

