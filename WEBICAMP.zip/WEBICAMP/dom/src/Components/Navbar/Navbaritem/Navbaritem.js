import React from "react"
import {Link} from "react-router-dom"


const navbaritem=(props)=>{
    return(
        <div >
            <h1 className="center">
            <Link to={props.to}>{props.content}</Link>
            </h1>
        </div>
    );
}

export  default navbaritem;
