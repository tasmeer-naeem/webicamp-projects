import React from "react";
import "./Navbar.css"
import {Link} from "react-router-dom"
//import Navbaritem from "./Navbaritem/Navbaritem";


const Navbar=()=>{
return(
    <div className="H2">
   <h2 className="center"><Link to="/">home</Link></h2>
   <h2 className="center"><Link to="/About">About</Link></h2>
   <h2 className="center"><Link to="/Contact">Contact</Link></h2>
   </div>

)
}

export default Navbar; 