const express = require('express');
const { pushNotification } = require('../controllers/notificationController');

const router = express.Router();

// router.post("/", pushNotification)

module.exports = router;